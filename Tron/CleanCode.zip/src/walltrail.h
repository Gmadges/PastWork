#ifndef WALLTRAIL_H
#define WALLTRAIL_H

class WallTrail
{
public:
    WallTrail();
};

#endif // WALLTRAIL_H
